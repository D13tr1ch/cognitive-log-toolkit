# Verifier script
