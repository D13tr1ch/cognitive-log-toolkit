# Scoring logic
